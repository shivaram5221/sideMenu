import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'sidemenu';
  menu = [
    {
      title: "Dashboard",
      id:'menuitem1',
          url: "/dashboard",
          target: "_blank"
      },
      {
      title: "Product",
      id:'menuitem2',
      url:'/product',
          active: true,
          navigationItems: [
              {
                title: "Add Product",
                url: "/product/add-product"
              },
              {
                title: "Product Details",
                url: "/product/product-details",
                
              }
          ]
      }
  ]
}
