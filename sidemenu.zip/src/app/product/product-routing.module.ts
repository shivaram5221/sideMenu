import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductComponent } from './product.component';
import { AddProductComponent } from './add-product/add-product.component';
import { ProductDetailsComponent } from './product-details/product-details.component';



const routes: Routes = [
  { path: '', component: ProductComponent , data: { title: 'product'  } },
  { path: 'add-product', component: AddProductComponent , data: { title: 'product'  } },
  { path: 'product-details', component: ProductDetailsComponent , data: { title: 'product'  } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductRoutingModule { }
